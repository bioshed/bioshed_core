VERSION
v0.1.5 (beta)

INSTALLATION
$ pip install bioshed

DOCUMENTATION
See https://www.bioshed.io/docs
Or just type "bioshed" on the command line to see the help menu.
